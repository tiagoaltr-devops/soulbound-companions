# Soulbound Companions — Texturas conceituais implementáveis

Pacote de 12 texturas PNG 16×16 (RGBA) e quatro modelos JSON de blocos cúbicos vanilla.

## Componentes
- `soul_forge`: Forja da Alma
- `offering_altar`: Altar de Oferenda
- `ritual_stone`: Pedra Ritualística
- `xp_platform`: Plataforma de XP

## Integração
1. Copiar `assets/soulbound/textures/block/*.png` para `src/main/resources/assets/soulbound/textures/block/`.
2. Conferir os IDs REAIS de blocos registrados no código. Renomear os quatro modelos conforme os IDs, se necessário, antes de copiar para `assets/soulbound/models/block/`.
3. Confirmar `blockstates/<id>.json` com `variants: {"": {"model": "soulbound:block/<id>"}}` (ou preservar estados e rotações existentes).
4. Conferir os modelos de item (`models/item/<id>.json`), normalmente com parent `soulbound:block/<id>`.
5. Preservar lógica de multibloco, receitas, SavedData e identidade.
6. Modelos fornecidos são cubos texturizados de referência; pedestais 3D exigem geometria adicional em Blockbench/JSON.
7. A arte azul é emissiva apenas visualmente; iluminação real requer configuração de renderização/light emission apropriada.

Não substituir automaticamente arquivos existentes sem comparar IDs, blockstates e modelos.
